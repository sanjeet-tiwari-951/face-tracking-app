'use client';

import React, { useRef, useEffect, useState } from "react";
import * as faceapi from "face-api.js";

const CameraFeed = () => {
  const videoRef = useRef();
  const canvasRef = useRef();
  const [recording, setRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const chunks = useRef([]);

  const loadModels = async () => {
    await faceapi.nets.tinyFaceDetector.loadFromUri("/models");
    await faceapi.nets.faceLandmark68Net.loadFromUri("/models");
  };

  const startVideo = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    videoRef.current.srcObject = stream;
  };

  const detectFace = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    setInterval(async () => {
      const detections = await faceapi
        .detectAllFaces(video, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks();
      const resized = faceapi.resizeResults(detections, {
        width: video.width,
        height: video.height,
      });
      canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
      faceapi.draw.drawDetections(canvas, resized);
    }, 100);
  };

  const startRecording = () => {
    const stream = canvasRef.current.captureStream(30);
    const recorder = new MediaRecorder(stream);
    recorder.ondataavailable = (e) => chunks.current.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunks.current, { type: "video/webm" });
      const url = URL.createObjectURL(blob);
      localStorage.setItem("savedVideo", url);
      chunks.current = [];
    };
    recorder.start();
    setMediaRecorder(recorder);
    setRecording(true);
  };

  const stopRecording = () => {
    mediaRecorder.stop();
    setRecording(false);
  };

  useEffect(() => {
    loadModels().then(startVideo);
  }, []);

  useEffect(() => {
    videoRef.current && detectFace();
  }, []);

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative">
        <video ref={videoRef} autoPlay muted width="640" height="480" className="rounded-xl" />
        <canvas ref={canvasRef} width="640" height="480" className="absolute top-0 left-0" />
      </div>
      <div className="space-x-4">
        {!recording ? (
          <button onClick={startRecording} className="bg-green-500 text-white px-4 py-2 rounded">
            Start Recording
          </button>
        ) : (
          <button onClick={stopRecording} className="bg-red-500 text-white px-4 py-2 rounded">
            Stop Recording
          </button>
        )}
      </div>
    </div>
  );
};

export default CameraFeed;