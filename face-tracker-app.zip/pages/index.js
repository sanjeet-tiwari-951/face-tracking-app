import Head from "next/head";
import CameraFeed from "../components/CameraFeed";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <Head>
        <title>Face Tracker App</title>
      </Head>
      <h1 className="text-3xl font-bold mb-6">Face Tracking & Recording App</h1>
      <CameraFeed />
    </div>
  );
}